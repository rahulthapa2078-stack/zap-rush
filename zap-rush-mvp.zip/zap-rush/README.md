# Zap Rush ⚡

A mobile-first, real-time multiplayer reflex game. This first milestone implements room creation/joining, a 3–4 player lobby, server-authoritative false starts and winner selection, one normal reaction round, results, host handoff, and reconnect tokens.

## Requirements
- Node.js 20+
- npm

## Run locally
```bash
npm install
npm start
```
Open http://localhost:3000. To test on multiple devices on the same Wi-Fi, open `http://YOUR_COMPUTER_LAN_IP:3000` on each device. For friends outside your network, deploy the server publicly (see below).

## Deploy publicly
This app requires a persistent Node process and WebSocket support. It is suitable for Render, Railway, Fly.io, or another Node host.

### Render quick setup
1. Push this folder to a GitHub repository.
2. Create a new **Web Service** from that repository in Render.
3. Build command: `npm install`
4. Start command: `npm start`
5. No environment variables are required for the single-origin deployment.
6. Wait for the service to become live, then share its `https://...onrender.com` URL.

The `/health` endpoint returns `{ "ok": true }` for health checks.

## Current milestone scope
- One normal reaction round (the first playable slice), not yet the complete 10-round match.
- Server uses its monotonic clock to measure elapsed time from target reveal to accepted tap. Winner is first valid tap received by the server; internet latency still affects arrival order.
- Room state is in memory. A server restart clears active rooms; durable storage and production scaling are future work.
- Reconnection token is stored in localStorage. Rejoin restores the player's existing identity and score while the room remains in memory.
- Background music toggle is a placeholder; sound effects use Web Audio and can be muted.
- Twist rounds, full 10-round progression, podium, and production hardening are intentionally deferred until this slice is tested.

## Security / production notes
For a public competitive release, add rate limiting, stricter origin policy, room/player expiry, abuse controls, persistent room state, and automated integration tests. The current server is authoritative for game outcomes but does not eliminate network-latency differences.

A `render.yaml` Blueprint file is included for a straightforward Render deployment. The free service may sleep when idle, so the first room after a period of inactivity can take longer to connect.
